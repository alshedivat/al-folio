#%%
import polars as pl
from polars import col, lit
import os
from tqdm import tqdm

#%%
dt = pl.read_csv("RevelioLabs_LocationSample_Nov22.csv")

countries = dt["country"].unique().sort().to_list()

os.system("rm -r -f dt_by_country")
os.mkdir("dt_by_country")

#%%

# Run for all countries
for country in tqdm(countries):
    
    # Save data for each country
    file_loc = os.path.join("dt_by_country", f"{country}.csv").replace(" ", "_")
    dt.filter(col("country") == country).write_csv(file_loc)

    # Run create_geographic_clusters.py for each country (overwrites the file)
    os.system(f"python create_geographic_clusters.py --in_path {file_loc} --out_path {file_loc} --arg_path optimal_parameters.json")


#%%
# Save into a single file

dt = [
        pl.read_csv(
            file = os.path.join("dt_by_country", f),
            columns=["city", "state", "country", "latitude",        "longitude", "population", "msa", "cc_id"],
            dtypes={"cc_id": pl.Int32}
            )
    for f in os.listdir("dt_by_country")
    ]

dt = pl.concat(dt)

dt = dt.with_column(
        pl.when(
            col("cc_id").is_not_null()
            ).then(
                col("country") + "_" + col("cc_id")
                ).otherwise(
                    lit("")
                    ).alias("cluster")
    )

dt = dt.drop(["cc_id"])

dt.write_csv("SzymonSacher_RevelioLabs_LocationSample_Nov22.csv")