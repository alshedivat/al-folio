import polars as pl
from polars import col, lit
import numpy as np
import pandas as pd
import networkx as nx
import argparse
import json


class create_geographic_clusters:
    def __init__(self, dt):
        self.dt = dt
        self.pairs = self.create_pairs_df()

    def distance(self, s_lat, s_lng, e_lat, e_lng):
        """
        Calculate the distance (KM) between two points on the earth (in decimal degrees)
        """

        # approximate radius of earth in km
        R = 6373.0

        s_lat = s_lat * np.pi / 180.0
        s_lng = np.deg2rad(s_lng)
        e_lat = np.deg2rad(e_lat)
        e_lng = np.deg2rad(e_lng)

        d = (
            np.sin((e_lat - s_lat) / 2) ** 2
            + np.cos(s_lat) * np.cos(e_lat) * np.sin((e_lng - s_lng) / 2) ** 2
        )

        return 2 * R * np.arcsin(np.sqrt(d))

    def create_pairs_df(self):
        """
        Create a dataframe with all pairs of locations
        """

        # Compute the haversine distance between each location
        pairs = (
            self.dt.select(["loc_id", "latitude", "longitude", "population"])
            .join(
                # Cross join with itself
                self.dt.select(
                    [
                        col("loc_id").suffix("2"),
                        col("latitude").suffix("2"),
                        col("longitude").suffix("2"),
                        col("population").suffix("2"),
                    ]
                ),
                how="cross",
            )
            .filter(  # Keep only pairs where loc_id < loc_id2  (to avoid duplicates)
                col("loc_id") < col("loc_id2")
            )
            .with_column(  # Compute the distance
                self.distance(
                    col("latitude"),
                    col("longitude"),
                    col("latitude2"),
                    col("longitude2"),
                ).alias("distance")
            )
        )

        return pairs

    def find_components(self, max_dist, min_pops):
        """
        Find connected components in a distance matrix

        Parameters:
        dist (DataFrame): A DataFrame with columns "loc_id", "loc_id2", "distance",
            "population", "population2"
        max_dist (float): The maximum distance between two locations to be considered connected
        min_pops (int): The minimum population of a locations to be considered connected
        """

        # Filter the distance matrix
        dist = self.pairs.filter(
            (col("distance") <= max_dist)
            & (col("population") >= min_pops)
            & (col("population2") >= min_pops)
        )

        # Create a graph
        g = nx.from_pandas_edgelist(
            dist, source="loc_id", target="loc_id2", edge_attr="distance"
        )

        # Find connected components
        components = list(nx.connected_components(g))

        # Create a dataframe with the connected components
        components_df = pl.DataFrame(
            {
                "cc_id": [i for i, c in enumerate(components) for _ in range(len(c))],
                "loc_id": [l for c in components for l in c],
            }
        )

        # Merge the components with the original dataframe
        return components_df


# Run the code
if __name__ ==  "__main__":

    parser = argparse.ArgumentParser(description="Find clusters of locations")

    parser.add_argument(
        "--in_path", type=str, default=None
    )
    parser.add_argument(
        "--out_path",
        type=str,
        default=None,
    )
    parser.add_argument("--arg_path", type=str, default=None)
    parser.add_argument("--max_dist", type=float, default=None)
    parser.add_argument("--min_pops", type=int, default=None)
    parser.add_argument("--verbose", action="store_true", default=False)

    args = parser.parse_args()


    if args.arg_path is not None:
        with open(args.arg_path, "r") as f:
            args_optimized = json.load(f)

    if args.max_dist is not None:
        pass
    elif args.max_dist is None and args_optimized is not None:
        args.max_dist = args_optimized["max_dist"]
    else:
        raise ValueError("max_dist must be specified")

    if args.min_pops is not None:
        pass
    elif args.min_pops is None and args_optimized is not None:
        args.min_pops = args_optimized["min_pops"]
    else:
        raise ValueError("min_pops must be specified")

    # Read the data
    if args.verbose:
        print("Reading data")

    dt = (
        pl.scan_csv(
            args.in_path,
        )
        .sort(col("longitude"), reverse=True)
        .with_row_count("loc_id")  # Primary Key
        .with_column(pl.col("loc_id").cast(pl.Int32))
        .collect()
    )

    # Assert unique and create a primary key
    assert dt.unique().shape[0] == dt.shape[0]

    # Initialize the class
    create_geographic_clusters_obj = create_geographic_clusters(dt)

    # Find connected components
    if args.verbose:
        print("Finding connected components")

    components_df = create_geographic_clusters_obj.find_components(
        args.max_dist, args.min_pops
    ).with_column(col("loc_id").cast(pl.Int32))

    # Merge the connected components with the original dataframe
    dt = dt.join(components_df, on="loc_id", how="left")

    # Save the results
    if args.verbose:
        print("Saving results")
        
    dt.write_csv(args.out_path)
