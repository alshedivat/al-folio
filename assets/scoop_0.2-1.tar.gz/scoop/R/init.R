.onAttach <- function(libname, pkgname){
  cat(""                                                                      ,
      "----------------------------------------------------------------------",
      ""                                                                      ,
      "      'scoop' package version 0.2-1"                                   ,
      "      Web page (http://stat.genopole.cnrs.fr/logiciels/scoop)"         ,
      ""                                                                      ,
      "----------------------------------------------------------------------",
      " This is an early/experimental version for reviewing process          ",
      "----------------------------------------------------------------------",
      sep = "\n")
}
